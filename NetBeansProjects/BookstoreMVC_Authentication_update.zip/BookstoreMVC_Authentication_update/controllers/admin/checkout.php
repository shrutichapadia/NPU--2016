<?php

/* 


 * Student Info: Name=Chapadia Shruti, ID=15574CS

 * Subject: CS526(B)_HWNo3_Summer_2016

 * Author: shruti

 * Filename: checkout.php

 * Date and Time: Jul 29, 2016 5:37:48 PM

 * Project Name: BookstoreMVC_Authentication_update


 */


