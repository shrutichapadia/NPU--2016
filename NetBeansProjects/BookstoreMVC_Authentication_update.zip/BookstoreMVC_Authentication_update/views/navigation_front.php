<?php

/* 


 * Student Info: Name=Chapadia Shruti, ID=15574CS

 * Subject: CS526(B)_HWNo3_Summer_2016

 * Author: shruti

 * Filename: navigation_front.php

 * Date and Time: Jul 27, 2016 10:07:27 AM

 * Project Name: BookstoreMVC_Authentication_update


 */

return "
<nav>
    <a href='index.php?controller=guest'>Searching Books</a>
    <a href='index.php?controller=admin'>Managing Books</a>
</nav>
";
