<?php

/* 


 * Student Info: Name=Chapadia Shruti, ID=15574CS

 * Subject: CS526(B)_HWNo3_Summer_2016

 * Author: shruti

 * Filename: navigation.php

 * Date and Time: Jul 27, 2016 10:07:38 AM

 * Project Name: BookstoreMVC_Authentication_update


 */



return "
<nav>
    <a href='index.php?controller=admin&action=index'>book_list</a>
    <a href='index.php?controller=admin&action=index'>Add New book</a>
</nav>
";