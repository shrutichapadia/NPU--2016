
/*


 * Student Info: Name=ChapadiaShruti, ID=15574CS

 * Subject: CS532(B)_HWN3_Summer_2016

 * Author: shruti

 * Filename: chateasyconstants.java

 * Date and Time: Jul 8, 2016 10:36:07 PM

 * Project Name: chateasy


 */
/**
 *
 * @author shruti
 */
package chateasy;

/**
 *
 * @author shruti
 */
public interface chateasyconstants {
     
    public static String user1 = "";
    public static String user2 ="";
    public static int User1 = 0;
    public static int User2 =0;
    
    

}
